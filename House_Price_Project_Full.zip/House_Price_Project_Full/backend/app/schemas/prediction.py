# Pydantic schema for validating prediction requests
from pydantic import BaseModel, Field


class PredictionRequest(BaseModel):
    carpet_area_sqft: float = Field(gt=0)
    floor_num: int
    bathroom: int
    balcony: int
    car_parking: int
    location: str
    Transaction: str
    Furnishing: str
    facing: str
    overlooking: str
    Ownership: str


# Pydantic schema for the prediction response
class PredictionResponse(BaseModel):
    predicted_price: float    