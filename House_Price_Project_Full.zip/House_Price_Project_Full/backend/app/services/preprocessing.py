# Convert a prediction request into a one-row DataFrame
import pandas as pd

from app.schemas.prediction import PredictionRequest


def build_input_dataframe(request: PredictionRequest) -> pd.DataFrame:
    # Create one row with exactly the feature names used by the ML pipeline
    data = {
        "carpet_area_sqft": [request.carpet_area_sqft],
        "floor_num": [request.floor_num],
        "bathroom": [request.bathroom],
        "balcony": [request.balcony],
        "car_parking": [request.car_parking],
        "location": [request.location],
        "Transaction": [request.Transaction],
        "Furnishing": [request.Furnishing],
        "facing": [request.facing],
        "overlooking": [request.overlooking],
        "Ownership": [request.Ownership],
    }

    # Convert the dictionary into a one-row DataFrame
    return pd.DataFrame(data)