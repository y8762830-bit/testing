# Model loading and prediction logic

import joblib
import pandas as pd
from pathlib import Path


# Build the path to the trained model file
MODEL_PATH = Path(__file__).resolve().parents[2] / "models" / "house_price.pkl"


# This variable will hold the trained model
model = None


def load_model():
    # Load the trained ML pipeline once at application startup
    global model
    model = joblib.load(MODEL_PATH)


def predict_price(input_data: pd.DataFrame) -> float:
    # Make sure the model has been loaded
    if model is None:
        raise RuntimeError("Model is not loaded.")

    # Generate the house price prediction
    prediction = model.predict(input_data)

    # Return the first prediction as a float
    return float(prediction[0])


# Load the trained model when this module is imported
load_model()