# Main FastAPI application

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes.prediction import router as prediction_router
from app.services.inference import load_model


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Load the trained ML model once when the application starts
    load_model()

    yield


# Create the FastAPI application
app = FastAPI(
    title="House Price Prediction API",
    lifespan=lifespan,
)


# Allow requests from the frontend application
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Register the prediction routes
app.include_router(prediction_router)


# Health check endpoint
@app.get("/health")
def health_check():
    return {"status": "ok"}