# Tests for the house price prediction API

from fastapi.testclient import TestClient

from app.main import app


# Create a test client for the FastAPI application
client = TestClient(app)


def test_prediction_success():
    # Send valid house data to the prediction endpoint
    response = client.post(
        "/predict",
        json={
            "carpet_area_sqft": 500,
            "floor_num": 10,
            "bathroom": 2,
            "balcony": 1,
            "car_parking": 1,
            "location": "mumbai",
            "Transaction": "Resale",
            "Furnishing": "Unfurnished",
            "facing": "East",
            "overlooking": "Garden/Park",
            "Ownership": "Freehold",
        },
    )

    # The API should accept the valid request
    assert response.status_code == 200

    # The response should contain a predicted price
    assert "predicted_price" in response.json()


def test_prediction_invalid_input():
    # Send invalid data to test FastAPI validation
    response = client.post(
        "/predict",
        json={
            "carpet_area_sqft": -500,
            "floor_num": 10,
            "bathroom": 2,
            "balcony": 1,
            "car_parking": 1,
            "location": "mumbai",
            "Transaction": "Resale",
            "Furnishing": "Unfurnished",
            "facing": "East",
            "overlooking": "Garden/Park",
            "Ownership": "Freehold",
        },
    )

    # The API should reject invalid input
    assert response.status_code == 422
    