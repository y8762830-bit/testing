import { Link } from 'react-router-dom'

interface Props {
  price: number | null
}

export default function ResultPage({ price }: Props) {
  if (price === null) return null

  return (
    <main className="page-shell result-shell">
      <section className="result-card">
        <span className="eyebrow">PREDICTION RESULT</span>
        <h1>Estimated House Price</h1>
        <div className="price">₹ {price.toLocaleString('en-IN', { maximumFractionDigits: 2 })}</div>
        <p>This is the price predicted by the machine-learning model.</p>
        <Link className="secondary-button" to="/">Predict Another Property</Link>
      </section>
    </main>
  )
}
