import { Link } from 'react-router-dom'

export default function NotFoundPage() {
  return (
    <main className="page-shell result-shell">
      <section className="result-card">
        <span className="eyebrow">404</span>
        <h1>Page Not Found</h1>
        <p>The page you are looking for does not exist.</p>
        <Link className="secondary-button" to="/">Back to Home</Link>
      </section>
    </main>
  )
}
