import { useNavigate } from 'react-router-dom'
import PredictionForm from '../components/PredictionForm'

interface Props {
  onPrediction: (price: number) => void
}

export default function HomePage({ onPrediction }: Props) {
  const navigate = useNavigate()

  const handlePrediction = (price: number) => {
    onPrediction(price)
    navigate('/result')
  }

  return (
    <main className="page-shell">
      <section className="hero">
        <span className="eyebrow">ML POWERED</span>
        <h1>House Price Prediction</h1>
        <p>Enter the property details below to get an estimated house price.</p>
      </section>
      <section className="card">
        <PredictionForm onPrediction={handlePrediction} />
      </section>
    </main>
  )
}
