import type { PredictionRequest, PredictionResponse } from '../types/prediction'

const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000').replace(/\/$/, '')

export async function predictPrice(data: PredictionRequest): Promise<PredictionResponse> {
  const response = await fetch(`${API_BASE_URL}/predict`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  })

  if (!response.ok) {
    let message = 'Prediction request failed.'
    try {
      const error = await response.json()
      if (Array.isArray(error?.detail)) {
        message = error.detail
          .map((item: { loc?: string[]; msg?: string }) => `${item.loc?.at(-1) ?? 'field'}: ${item.msg ?? 'Invalid input'}`)
          .join(' • ')
      } else if (typeof error?.detail === 'string') {
        message = error.detail
      }
    } catch {
      // Keep the generic message when the backend does not return JSON.
    }
    throw new Error(message)
  }

  return response.json() as Promise<PredictionResponse>
}

export async function checkHealth(): Promise<boolean> {
  try {
    const response = await fetch(`${API_BASE_URL}/health`)
    return response.ok
  } catch {
    return false
  }
}

export async function loadLocations(): Promise<string[]> {
  const response = await fetch('/locations.json', { cache: 'no-store' })
  if (!response.ok) throw new Error('Could not load locations.')
  const data: unknown = await response.json()
  if (!Array.isArray(data)) throw new Error('Invalid locations file.')
  return data.filter((item): item is string => typeof item === 'string')
}
