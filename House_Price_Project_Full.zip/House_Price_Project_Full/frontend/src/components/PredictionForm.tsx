import { useEffect, useMemo, useState } from 'react'
import type { PredictionRequest } from '../types/prediction'
import { loadLocations, predictPrice } from '../api/predictionClient'

interface Props {
  onPrediction: (price: number) => void
}

const transactionOptions = ['Resale', 'New Property', 'Other', 'Rent/Lease']
const furnishingOptions = ['Semi-Furnished', 'Unfurnished', 'Furnished']
const facingOptions = ['East', 'North - East', 'North', 'West', 'South', 'North - West', 'South - East', 'South -West']
const ownershipOptions = ['Freehold', 'Leasehold', 'Co-operative Society', 'Power Of Attorney']
// NOTE: this list must exactly match the categories the OneHotEncoder was
// fit on (see ohe.categories_ in the training notebook). Two combinations
// that used to be here ("Garden/Park, Pool, Main Road, Not Available" and
// "Pool, Main Road, Garden/Park, Not Available") were never seen by the
// model, so OneHotEncoder(handle_unknown="ignore") would silently zero out
// the whole "overlooking" feature for those selections instead of using it.
const overlookingOptions = [
  'Main Road',
  'Garden/Park, Main Road',
  'Garden/Park',
  'Garden/Park, Pool, Main Road',
  'Pool, Garden/Park, Main Road',
  'Garden/Park, Pool',
  'Main Road, Garden/Park, Pool',
  'Pool, Main Road',
  'Pool',
  'Main Road, Garden/Park',
  'Pool, Garden/Park',
  'Garden/Park, Main Road, Pool',
  'Main Road, Pool',
  'Main Road, Pool, Garden/Park',
  'Pool, Main Road, Garden/Park',
  'Main Road, Not Available',
  'Garden/Park, Not Available',
]

const initialForm: PredictionRequest = {
  carpet_area_sqft: 0,
  floor_num: 0,
  bathroom: 0,
  balcony: 0,
  car_parking: 0,
  location: '',
  Transaction: '',
  Furnishing: '',
  facing: '',
  overlooking: '',
  Ownership: '',
}

export default function PredictionForm({ onPrediction }: Props) {
  const [form, setForm] = useState<PredictionRequest>(initialForm)
  const [locations, setLocations] = useState<string[]>([])
  const [locationsError, setLocationsError] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    loadLocations()
      .then(setLocations)
      .catch(() => setLocationsError('Locations could not be loaded. Please try again later.'))
  }, [])

  const locationOptions = useMemo(() => locations, [locations])

  const update = <K extends keyof PredictionRequest>(key: K, value: PredictionRequest[K]) => {
    setForm((current) => ({ ...current, [key]: value }))
    setError('')
  }

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setError('')

    if (form.carpet_area_sqft <= 0) {
      setError('Carpet Area must be greater than 0.')
      return
    }

    if (form.floor_num < -1) {
      setError('Floor Number cannot be less than -1.')
      return
    }

    if (form.bathroom < 0 || form.balcony < 0 || form.car_parking < 0) {
      setError('Bathrooms, balconies, and car parking cannot be negative.')
      return
    }

    const requiredFields: Array<keyof PredictionRequest> = [
      'location', 'Transaction', 'Furnishing', 'facing', 'overlooking', 'Ownership',
    ]

    if (requiredFields.some((field) => !String(form[field]).trim())) {
      setError('Please complete all dropdown fields.')
      return
    }

    setLoading(true)
    try {
      const result = await predictPrice(form)
      onPrediction(result.predicted_price)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <form className="prediction-form" onSubmit={handleSubmit} noValidate>
      <div className="form-grid">
        <NumberField
          label="Carpet Area (sqft)"
          value={form.carpet_area_sqft}
          min={0}
          step="0.01"
          placeholder="e.g. 1200"
          onChange={(value) => update('carpet_area_sqft', value)}
        />
        <NumberField label="Floor Number" value={form.floor_num} min={-1} step="1" onChange={(value) => update('floor_num', value)} />
        <NumberField label="Bathrooms" value={form.bathroom} min={0} step="1" onChange={(value) => update('bathroom', value)} />
        <NumberField label="Balconies" value={form.balcony} min={0} step="1" onChange={(value) => update('balcony', value)} />
        <NumberField label="Car Parking" value={form.car_parking} min={0} step="1" onChange={(value) => update('car_parking', value)} />

        <Select label="Location" value={form.location} options={locationOptions} placeholder="Select location" onChange={(value) => update('location', value)} />
        <Select label="Transaction" value={form.Transaction} options={transactionOptions} placeholder="Select transaction" onChange={(value) => update('Transaction', value)} />
        <Select label="Furnishing" value={form.Furnishing} options={furnishingOptions} placeholder="Select furnishing" onChange={(value) => update('Furnishing', value)} />
        <Select label="Facing" value={form.facing} options={facingOptions} placeholder="Select facing" onChange={(value) => update('facing', value)} />
        <Select label="Overlooking" value={form.overlooking} options={overlookingOptions} placeholder="Select overlooking" onChange={(value) => update('overlooking', value)} />
        <Select label="Ownership" value={form.Ownership} options={ownershipOptions} placeholder="Select ownership" onChange={(value) => update('Ownership', value)} />
      </div>

      {locationsError && <p className="notice" role="status">{locationsError}</p>}
      {error && <p className="error" role="alert">{error}</p>}

      <button className="predict-button" type="submit" disabled={loading || locations.length === 0}>
        {loading ? 'Predicting...' : 'Predict Price'}
      </button>
    </form>
  )
}

function NumberField({
  label, value, min, step, placeholder, onChange,
}: {
  label: string
  value: number
  min: number
  step: string
  placeholder?: string
  onChange: (value: number) => void
}) {
  return (
    <label>
      {label}
      <input
        type="number"
        min={min}
        step={step}
        value={Number.isNaN(value) ? '' : value}
        placeholder={placeholder}
        onChange={(event) => onChange(Number(event.target.value))}
        required
      />
    </label>
  )
}

function Select({
  label, value, options, placeholder, onChange,
}: {
  label: string
  value: string
  options: string[]
  placeholder: string
  onChange: (value: string) => void
}) {
  return (
    <label>
      {label}
      <select value={value} onChange={(event) => onChange(event.target.value)} required>
        <option value="">{placeholder}</option>
        {options.map((option) => <option key={option} value={option}>{option}</option>)}
      </select>
    </label>
  )
}
