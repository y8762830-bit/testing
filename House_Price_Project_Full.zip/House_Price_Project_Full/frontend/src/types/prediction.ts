export interface PredictionRequest {
  carpet_area_sqft: number
  floor_num: number
  bathroom: number
  balcony: number
  car_parking: number
  location: string
  Transaction: string
  Furnishing: string
  facing: string
  overlooking: string
  Ownership: string
}

export interface PredictionResponse {
  predicted_price: number
}
