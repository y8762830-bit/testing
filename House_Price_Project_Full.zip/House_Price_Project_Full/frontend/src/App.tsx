import { useState } from 'react'
import { Navigate, Route, Routes } from 'react-router-dom'
import HomePage from './pages/HomePage'
import ResultPage from './pages/ResultPage'
import NotFoundPage from './pages/NotFoundPage'
import './styles.css'

function App() {
  const [price, setPrice] = useState<number | null>(null)

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">HousePrice<span>AI</span></div>
      </header>

      <Routes>
        <Route path="/" element={<HomePage onPrediction={(value) => setPrice(value)} />} />
        <Route path="/result" element={price === null ? <Navigate to="/" replace /> : <ResultPage price={price} />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>

      <footer>House Price Prediction • React + FastAPI</footer>
    </div>
  )
}

export default App
