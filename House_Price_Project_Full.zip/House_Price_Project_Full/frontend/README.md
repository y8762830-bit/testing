# House Price Prediction — Frontend

React + TypeScript + Vite frontend for the House Price Prediction project.

## Backend contract

The frontend sends `POST /predict` to the URL in `VITE_API_BASE_URL`.

### Request fields

- `carpet_area_sqft`
- `floor_num`
- `bathroom`
- `balcony`
- `car_parking`
- `location`
- `Transaction`
- `Furnishing`
- `facing`
- `overlooking`
- `Ownership`

### Expected response

```json
{
  "predicted_price": 4250000
}
```

## Setup

1. Install Node.js 18+.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Keep `VITE_API_BASE_URL=http://127.0.0.1:8000` when the backend runs locally.
5. Run `npm run dev`.
6. Open the URL shown by Vite, normally `http://localhost:5173`.

## Build

Run `npm run build` to create the production build in `dist/`.

## Project structure

```text
frontend/
├── public/
│   └── locations.json
├── src/
│   ├── api/predictionClient.ts
│   ├── components/PredictionForm.tsx
│   ├── pages/HomePage.tsx
│   ├── pages/ResultPage.tsx
│   ├── pages/NotFoundPage.tsx
│   ├── types/prediction.ts
│   ├── App.tsx
│   ├── main.tsx
│   └── styles.css
├── .env.example
├── package.json
└── vite.config.ts
```

## Notes

- `locations.json` is the exported location list used by the ML project.
- The frontend does not load or ship the `.pkl` model; the FastAPI backend handles model inference.
- The dropdown values match the categorical values found in the provided house-price dataset.
