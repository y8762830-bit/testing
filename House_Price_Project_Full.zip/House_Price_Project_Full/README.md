# House Price Project — Full (Backend + Frontend)

## Backend (FastAPI, via Docker)

```bash
cd backend
docker build -t house-price-backend .
docker run -d -p 8000:8000 --name house-price-api house-price-backend
```

Check it's running:
```bash
curl http://localhost:8000/health
```

Swagger docs: http://localhost:8000/docs

## Frontend (React + Vite)

```bash
cd frontend
npm install
npm run dev
```

App will run on http://localhost:5173 (Vite will confirm exact port).

Make sure the frontend's API base URL points to `http://localhost:8000` where the backend is running.

## Notes

- The backend import bug (`app.inference` / `app.preprocessing` -> should be `app.services.inference` / `app.services.preprocessing`) has already been fixed in this copy.
- Run the backend first, then the frontend.
