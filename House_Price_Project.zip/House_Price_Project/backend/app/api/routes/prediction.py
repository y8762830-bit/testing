# API routes for house price prediction

from fastapi import APIRouter

from app.schemas.prediction import PredictionRequest, PredictionResponse
from app.preprocessing import build_input_dataframe
from app.inference import predict_price


router = APIRouter()


@router.post("/predict", response_model=PredictionResponse)
def predict(request: PredictionRequest):
    # Convert the request into a one-row DataFrame
    input_data = build_input_dataframe(request)

    # Generate the house price prediction
    predicted_price = predict_price(input_data)

    # Return the prediction in the API response format
    return PredictionResponse(predicted_price=predicted_price)